const express = require('express');
const app = express();
const port = 5000;

app.use(express.json()); // Permite recibir JSON en las solicitudes

let productos = []; // Array temporal para almacenar productos

// Ruta para obtener productos
app.get('/api/productos', (req, res) => {
    res.json(productos);
});

// Ruta para agregar un producto
app.post('/api/productos', (req, res) => {
    const { nombre, sku, precioEntrada, precioSalida, cantidad } = req.body;

    if (!nombre || !sku || !precioEntrada || !precioSalida || !cantidad) {
        return res.status(400).json({ message: "Todos los campos son obligatorios" });
    }

    const nuevoProducto = { id: productos.length + 1, nombre, sku, precioEntrada, precioSalida, cantidad };
    productos.push(nuevoProducto);

    res.status(201).json({ message: "Producto agregado correctamente", producto: nuevoProducto });
});

app.listen(port, () => {
    console.log(`Servidor corriendo en el puerto ${port}`);
});


//Eliminar un producto
app.delete('/api/productos/:id', (req, res) => {
    const id = parseInt(req.params.id); // Convertir el ID a número
    const index = productos.findIndex(p => p.id === id);

    if (index !== -1) {
        productos.splice(index, 1); // Eliminar el producto de la lista
        res.json({ mensaje: 'Producto eliminado correctamente' });
    } else {
        res.status(404).json({ mensaje: 'Producto no encontrado' });
    }
});

