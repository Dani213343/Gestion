const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    nombre: { type: String, required: true },
    codigo: { type: String, unique: true, required: true },
    sku: { type: String, unique: true, required: true },
    precioEntrada: { type: Number, required: true },
    precioSalida: { type: Number, required: true },
    cantidad: { type: Number, required: true },
    categoria: { type: String },
    fechaIngreso: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Product', productSchema);
